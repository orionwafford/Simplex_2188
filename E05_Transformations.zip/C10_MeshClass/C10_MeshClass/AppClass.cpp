#include "AppClass.h"

void Application::InitVariables(void)
{
	//Make MyMesh object
	m_pMesh = new MyMesh();
	m_pMesh->GenerateCube(1.0f, C_BLACK);

	//m_pMesh2 = new MyMesh();
	//m_pMesh2->GenerateCube(1.0f, C_BLACK);
}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();
	matrix4 m4View = m_pCameraMngr->GetViewMatrix();
	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix();

	//Didn't create vector for matricies since I would have to add them all to vector and then 
	//loop through them. And I would only loop through the vector once for this exercise.
	static float value = 0.0f;
	//col1
	matrix4 m4Translate = glm::translate(IDENTITY_M4, vector3( value + -5.0f, -1.0f,0.0f));
	matrix4 m4Translate2 = glm::translate(IDENTITY_M4, vector3(value + -5.0f, -0.0f, 0.0f));
	matrix4 m4Translate3 = glm::translate(IDENTITY_M4, vector3(value + -5.0f, 1.0f, 0.0f));
	//col2
	matrix4 m4Translate4 = glm::translate(IDENTITY_M4, vector3(value + -4.0f, 1.0f, 0.0f));
	matrix4 m4Translate5 = glm::translate(IDENTITY_M4, vector3(value + -4.0f, 2.0f, 0.0f));
	//col3
	matrix4 m4Translate6 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, -1.0f, 0.0f));
	matrix4 m4Translate7 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, 0.0f, 0.0f));
	matrix4 m4Translate8 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, 1.0f, 0.0f));
	matrix4 m4Translate9 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, 2.0f, 0.0f));
	matrix4 m4Translate10 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, 3.0f, 0.0f));
	matrix4 m4Translate11 = glm::translate(IDENTITY_M4, vector3(value + -3.0f, 5.0f, 0.0f));
	//col4
	matrix4 m4Translate12 = glm::translate(IDENTITY_M4, vector3(value + -2.0f, -2.0f, 0.0f));
	matrix4 m4Translate13 = glm::translate(IDENTITY_M4, vector3(value + -2.0f, 0.0f, 0.0f));
	matrix4 m4Translate14 = glm::translate(IDENTITY_M4, vector3(value + -2.0f, 1.0f, 0.0f));
	matrix4 m4Translate15 = glm::translate(IDENTITY_M4, vector3(value + -2.0f, 3.0f, 0.0f));
	matrix4 m4Translate16 = glm::translate(IDENTITY_M4, vector3(value + -2.0f, 4.0f, 0.0f));
	//col5
	matrix4 m4Translate17 = glm::translate(IDENTITY_M4, vector3(value + -1.0f, -2.0f, 0.0f));
	matrix4 m4Translate18 = glm::translate(IDENTITY_M4, vector3(value + -1.0f, 0.0f, 0.0f));
	matrix4 m4Translate19 = glm::translate(IDENTITY_M4, vector3(value + -1.0f, 1.0f, 0.0f));
	matrix4 m4Translate20 = glm::translate(IDENTITY_M4, vector3(value + -1.0f, 2.0f, 0.0f));
	matrix4 m4Translate21 = glm::translate(IDENTITY_M4, vector3(value + -1.0f, 3.0f, 0.0f));
	//col6
	matrix4 m4Translate22 = glm::translate(IDENTITY_M4, vector3(value + -0.0f, 0.0f, 0.0f));
	matrix4 m4Translate23 = glm::translate(IDENTITY_M4, vector3(value + -0.0f, 1.0f, 0.0f));
	matrix4 m4Translate24 = glm::translate(IDENTITY_M4, vector3(value + -0.0f, 2.0f, 0.0f));
	matrix4 m4Translate25 = glm::translate(IDENTITY_M4, vector3(value + -0.0f, 3.0f, 0.0f));
	//col7
	matrix4 m4Translate26 = glm::translate(IDENTITY_M4, vector3(value + 1.0f, -2.0f, 0.0f));
	matrix4 m4Translate27 = glm::translate(IDENTITY_M4, vector3(value +1.0f, 0.0f, 0.0f));
	matrix4 m4Translate28 = glm::translate(IDENTITY_M4, vector3(value + 1.0f, 1.0f, 0.0f));
	matrix4 m4Translate29 = glm::translate(IDENTITY_M4, vector3(value + 1.0f, 2.0f, 0.0f));
	matrix4 m4Translate30 = glm::translate(IDENTITY_M4, vector3(value + 1.0f, 3.0f, 0.0f));
	//col8
	matrix4 m4Translate31 = glm::translate(IDENTITY_M4, vector3(value + 2.0f, -2.0f, 0.0f));
	matrix4 m4Translate32 = glm::translate(IDENTITY_M4, vector3(value + 2.0f, 0.0f, 0.0f));
	matrix4 m4Translate33 = glm::translate(IDENTITY_M4, vector3(value + 2.0f, 1.0f, 0.0f));
	matrix4 m4Translate34 = glm::translate(IDENTITY_M4, vector3(value + 2.0f, 3.0f, 0.0f));
	matrix4 m4Translate35 = glm::translate(IDENTITY_M4, vector3(value + 2.0f, 4.0f, 0.0f));
	//col9
	matrix4 m4Translate36 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, -1.0f, 0.0f));
	matrix4 m4Translate37 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, 0.0f, 0.0f));
	matrix4 m4Translate38 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, 1.0f, 0.0f));
	matrix4 m4Translate39 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, 2.0f, 0.0f));
	matrix4 m4Translate40 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, 3.0f, 0.0f));
	matrix4 m4Translate41 = glm::translate(IDENTITY_M4, vector3(value + 3.0f, 5.0f, 0.0f));
	//col10
	matrix4 m4Translate42 = glm::translate(IDENTITY_M4, vector3(value + 4.0f, 1.0f, 0.0f));
	matrix4 m4Translate43 = glm::translate(IDENTITY_M4, vector3(value + 4.0f, 2.0f, 0.0f));
	//col11
	matrix4 m4Translate44 = glm::translate(IDENTITY_M4, vector3(value + 5.0f, -1.0f, 0.0f));
	matrix4 m4Translate45 = glm::translate(IDENTITY_M4, vector3(value + 5.0f, 0.0f, 0.0f));
	matrix4 m4Translate46 = glm::translate(IDENTITY_M4, vector3(value + 5.0f, 1.0f, 0.0f));

	value += 0.01f;
	//matrix4 m4Model = m4Translate;


	//Renders
	{
		m_pMesh->Render(m4Projection, m4View, m4Translate);
		m_pMesh->Render(m4Projection, m4View, m4Translate2);
		m_pMesh->Render(m4Projection, m4View, m4Translate3);
		m_pMesh->Render(m4Projection, m4View, m4Translate4);
		m_pMesh->Render(m4Projection, m4View, m4Translate5);
		m_pMesh->Render(m4Projection, m4View, m4Translate6);
		m_pMesh->Render(m4Projection, m4View, m4Translate7);
		m_pMesh->Render(m4Projection, m4View, m4Translate8);
		m_pMesh->Render(m4Projection, m4View, m4Translate9);
		m_pMesh->Render(m4Projection, m4View, m4Translate10);
		m_pMesh->Render(m4Projection, m4View, m4Translate11);
		m_pMesh->Render(m4Projection, m4View, m4Translate12);
		m_pMesh->Render(m4Projection, m4View, m4Translate13);
		m_pMesh->Render(m4Projection, m4View, m4Translate14);
		m_pMesh->Render(m4Projection, m4View, m4Translate15);
		m_pMesh->Render(m4Projection, m4View, m4Translate16);
		m_pMesh->Render(m4Projection, m4View, m4Translate17);
		m_pMesh->Render(m4Projection, m4View, m4Translate18);
		m_pMesh->Render(m4Projection, m4View, m4Translate19);
		m_pMesh->Render(m4Projection, m4View, m4Translate20);
		m_pMesh->Render(m4Projection, m4View, m4Translate21);
		m_pMesh->Render(m4Projection, m4View, m4Translate22);
		m_pMesh->Render(m4Projection, m4View, m4Translate23);
		m_pMesh->Render(m4Projection, m4View, m4Translate24);
		m_pMesh->Render(m4Projection, m4View, m4Translate25);
		m_pMesh->Render(m4Projection, m4View, m4Translate26);
		m_pMesh->Render(m4Projection, m4View, m4Translate27);
		m_pMesh->Render(m4Projection, m4View, m4Translate28);
		m_pMesh->Render(m4Projection, m4View, m4Translate29);
		m_pMesh->Render(m4Projection, m4View, m4Translate30);
		m_pMesh->Render(m4Projection, m4View, m4Translate31);
		m_pMesh->Render(m4Projection, m4View, m4Translate32);
		m_pMesh->Render(m4Projection, m4View, m4Translate33);
		m_pMesh->Render(m4Projection, m4View, m4Translate34);
		m_pMesh->Render(m4Projection, m4View, m4Translate35);
		m_pMesh->Render(m4Projection, m4View, m4Translate36);
		m_pMesh->Render(m4Projection, m4View, m4Translate37);
		m_pMesh->Render(m4Projection, m4View, m4Translate38);
		m_pMesh->Render(m4Projection, m4View, m4Translate39);
		m_pMesh->Render(m4Projection, m4View, m4Translate40);
		m_pMesh->Render(m4Projection, m4View, m4Translate41);
		m_pMesh->Render(m4Projection, m4View, m4Translate42);
		m_pMesh->Render(m4Projection, m4View, m4Translate43);
		m_pMesh->Render(m4Projection, m4View, m4Translate44);
		m_pMesh->Render(m4Projection, m4View, m4Translate45);
		m_pMesh->Render(m4Projection, m4View, m4Translate46);
	}


	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();
	
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();
	
	//draw gui
	DrawGUI();
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	if (m_pMesh != nullptr)
	{
		delete m_pMesh;
		m_pMesh = nullptr;
	}
	SafeDelete(m_pMesh);

	//release GUI
	ShutdownGUI();
}